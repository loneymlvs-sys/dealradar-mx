# DealRadar MX — Local PWA Prototype

**Status:** Working local prototype; **not** a live four-store scraper. Python 3.10+; standard library only.

## Run on Windows

1. Install Python 3.10+ and enable **Add Python to PATH**.
2. Extract the ZIP and open PowerShell inside `dealradar-mx`.
3. Run `python app.py --demo` to create clearly marked fictional examples (only on an empty database).
4. Visit `http://localhost:8080` on the same PC. Run `python app.py` later to keep existing data.
5. To start without sample products, run `python app.py` in a fresh directory/database.

Demo product URLs are deliberately nonfunctional and must never be treated as actual offers. The app supports verified manual observations, historical medians and alert candidates.

## Telegram alerts

1. Message `@BotFather` in Telegram, create a bot and copy its token.
2. Start a chat with the bot, then obtain your numeric chat ID from Telegram's Bot API (`getUpdates`) after sending a message to the bot.
3. In the **same PowerShell session** before starting the app:

```powershell
$env:TELEGRAM_BOT_TOKEN="YOUR_TOKEN"
$env:TELEGRAM_CHAT_ID="YOUR_CHAT_ID"
python app.py
```

Alerts send only when a **real** (non-demo) tracked product crosses from below 40% discount to at least 40% relative to the median of up to 30 previous observations. At least three earlier observations are required. Alerts are best effort: Telegram failures are printed to the server console, and this prototype has no retry queue. Repeated low prices do not trigger repeated Telegram messages. Do not share your bot token.

## Pricing methodology

Products are keyed by retailer + exact URL. Each verified observation is stored in SQLite. Baseline is the median of the previous up to 30 prices (at least 3 prior). Discount = max(0, (baseline - current)/baseline). A drop >=40% qualifies as a deal; >=60% is a *potential error*, not a verified pricing mistake. This is a basic anomaly detector, not a guarantee: stale, inflated, variant-mismatched, third-party, and shipping-adjusted prices may mislead. Confirm seller, specifications, stock, shipping and checkout price before purchasing.

## Store integration roadmap

- **Mercado Libre:** create a developer application, implement OAuth and use permitted item/search endpoints within granted scopes and rate limits. Validate availability of each endpoint for the app's permissions; no unauthenticated scraping fallback.
- **Amazon México:** seek approved Creators API access or another permitted commercial data source. Check the current Amazon Associates terms and mobile/PWA and aggregation restrictions *before* implementing it.
- **Coppel and Elektra:** request authorized product feeds/API access or partner permission. No undocumented scraping or CAPTCHA evasion.
- Build separate adapters that normalize `{store,title,category,url,price,currency,variant,condition,seller,stock,observed_at}`; only insert prices from authorized sources. Schedule polling on a hosted backend at retailer-permitted frequencies with backoff and observability.

## Security and deployment notes

This is **local-only** by design: it binds to `127.0.0.1` and has no user login, CSRF protection, HTTPS termination, persistent queue, or multi-user security. Do **not** expose this server publicly as-is. For production add authentication, rate limiting, input protection, secure secrets storage, HTTPS, database migrations/backups, Telegram retry queue, PWA icons/offline fallback, and a worker. Localhost supports service-worker registration, but a complete installable PWA needs proper icons and browser-specific installability checks. The PWA currently has a manifest and service worker shell, not full offline support.

## Automated tests

Run `python -m unittest discover -s tests -v`.
